import pandas as pd
import mysql.connector

# Đọc dữ liệu từ file Excel
df = pd.read_excel('dataadr.xlsx', sheet_name='Sheet1')

# Kết nối đến cơ sở dữ liệu MySQL
mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="29012002",
    database="homedata"
)

# Lưu dữ liệu vào cơ sở dữ liệu
mycursor = mydb.cursor()
mycursor.execute("SELECT name, latitude, longtitude FROM address")
data = mycursor.fetchall()
for d in data:
    print(d[0], d[1], d[2])
