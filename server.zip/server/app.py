from flask import Flask, render_template, request
from flask_cors import CORS
import os
import pandas as pd
import numpy as np
from sklearn import linear_model
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
import pandas as pd
import mysql.connector


app = Flask(__name__)
CORS(app)


def getAvgPrice(data, x, y):
    n, s = 0, 0
    for i in range(len(data['price'])):
        if (data['longtitude'][i] == x and data['latitude'][i] == y):
            s += data['price'][i]
            n += 1
    avg = int(s/n)
    return avg


def price_difference(avg, price):
    x = abs(avg - price)
    price = round(x)
    formatted_price = '{:,.0f}'.format(
        price).replace(',', '.') + ' VNĐ'
    return formatted_price


def getMaxPrice(data, x, y):
    s = 0
    for i in range(len(data['price'])):
        if (data['longtitude'][i] == x and data['latitude'][i] == y):
            s = max(s, data['price'][i])
    price = round(s)
    return price


def getData():
    # lấy dữ liệu từ file csv
    dataFile = None
    if os.path.exists('dataset.csv'):
        print("-- home_data.csv found locally")
        dataFile = pd.read_csv('dataset.csv', delimiter=';', engine='python')
    return dataFile


def linearRegressionModel(X_train, Y_train, X_test, Y_test, input_model):
    linear = linear_model.LinearRegression()
    # Training model
    linear.fit(X_train, Y_train)
    y_pred = linear.predict(X_test)
    # Tính toán R-squared trên tập kiểm tra
    r2 = r2_score(Y_test, y_pred)
    print("score:", r2)
    predicted_price = linear.predict(np.array(input_model))
    return predicted_price


def RegressionModel():
    data = getData()
    if data is not None:
        # Selection few attributes
        attributes = list(
            [
                'area',
                'bathroom',
                'bedroom',
                'longtitude',
                'latitude',
            ]
        )

        # Vector price of house
        Y = data['price']
        # print np.array(Y)
        # Vector attributes of house
        X = data[attributes]
        # Split data to training test and testing test
        X_train, X_test, Y_train, Y_test = train_test_split(
            np.array(X), np.array(Y), test_size=0.2)
        while True:
            linear = linear_model.LinearRegression()
            # Training model
            linear.fit(X_train, Y_train)
            y_pred = linear.predict(X_test)
            # Tính toán R-squared trên tập kiểm tra
            r2 = r2_score(Y_test, y_pred)
            print('train model:', r2)
            if r2 > 0.7:
                print("score:", r2)
                return linear


def predict_price(input_model, longtitude, latitude):
    predicted_price = linear.predict(np.array(input_model))
    price = round(predicted_price[0])
    # avg = getAvgPrice(data, longtitude, latitude)
    # max_price = getMaxPrice(data, longtitude, latitude)
    # price2 = abs(price-avg)
    # price3 = abs(max_price-price)

    formatted_price = '{:,.0f}'.format(price).replace(',', '.') + ' VNĐ'
    # formatted_price2 = '{:,.0f}'.format(price2).replace(',', '.') + ' VNĐ'
    # formatted_price3 = '{:,.0f}'.format(price3).replace(',', '.') + ' VNĐ'
    # formatted_avg = '{:,.0f}'.format(avg).replace(',', '.') + ' VNĐ'
    return formatted_price


linear = RegressionModel()


@app.route('/')
def home():
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="29012002",
        database="homedata"
    )
    mycursor = mydb.cursor()
    mycursor.execute("SELECT name, longtitude, latitude FROM address")
    data = mycursor.fetchall()
    return render_template('index.html', data=data)


@app.route('/api', methods=['POST'])
def sendRespone():
    if request.method == 'POST':
        # Lấy dữ liệu từ client
        data = request.get_json()
        square = int(data['area'])
        bedroom = int(data['Bedroom'])
        bathroom = int(data['Bathroom'])
        longtitude = int(data['longtitude'])
        latitude = int(data['latitude'])
        input_model = [[square, bedroom, bathroom, longtitude, latitude]]
        price = predict_price(input_model, longtitude, latitude)
        # Xử lý dữ liệu và trả về kết quả cho client
        print(price)
        return price


if __name__ == "__main__":
    app.run()
